<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-06-10 07:51:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\cms\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-06-10 07:51:10 --> Unable to connect to the database
ERROR - 2025-06-10 07:57:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'admin'@'localhost' (using password: YES) C:\xampp\htdocs\cms\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-06-10 07:57:36 --> Unable to connect to the database
ERROR - 2025-06-10 08:02:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'admin'@'localhost' (using password: YES) C:\xampp\htdocs\cms\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-06-10 08:02:39 --> Unable to connect to the database
ERROR - 2025-06-10 08:07:20 --> 404 Page Not Found: Media_library/images
ERROR - 2025-06-10 08:07:52 --> 404 Page Not Found: Admin/index
ERROR - 2025-06-10 08:07:57 --> 404 Page Not Found: Panel/index
ERROR - 2025-06-10 08:09:14 --> 404 Page Not Found: Admin/index
ERROR - 2025-06-10 08:09:20 --> 404 Page Not Found: Panel/index
ERROR - 2025-06-10 08:27:48 --> 404 Page Not Found: Install/index
ERROR - 2025-06-10 08:27:56 --> 404 Page Not Found: Media_library/images
ERROR - 2025-06-10 08:30:10 --> 404 Page Not Found: Media_library/images
ERROR - 2025-06-10 08:45:04 --> 404 Page Not Found: Media_library/images
ERROR - 2025-06-10 11:09:39 --> 404 Page Not Found: Views/themes
ERROR - 2025-06-10 11:09:39 --> 404 Page Not Found: Views/themes
ERROR - 2025-06-10 11:09:40 --> 404 Page Not Found: Views/themes
ERROR - 2025-06-10 11:09:40 --> 404 Page Not Found: Views/themes
ERROR - 2025-06-10 13:09:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 13:09:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 13:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 13:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 13:09:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 13:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 14:00:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 14:00:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 14:09:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 14:09:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:20:39 --> Severity: error --> Exception: syntax error, unexpected token ";" C:\xampp\htdocs\cms\views\themes\green_land\index.php 370
ERROR - 2025-06-10 15:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 15:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 15:21:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 15:21:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:13:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:13:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:20:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:24:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:24:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:24:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:24:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:25:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:25:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:27:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:27:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:28:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:28:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:29:42 --> 404 Page Not Found: Media_library/posts
ERROR - 2025-06-10 16:31:16 --> 404 Page Not Found: Media_library/posts
ERROR - 2025-06-10 16:32:30 --> 404 Page Not Found: Media_library/posts
ERROR - 2025-06-10 16:33:16 --> 404 Page Not Found: Media_library/posts
ERROR - 2025-06-10 16:42:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:42:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:42:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 16:42:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 17:38:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 17:38:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 23:44:28 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:31 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:32 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:32 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:32 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:32 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:33 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:33 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:33 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:33 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:33 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', NULL, 'literasi', '1')
ERROR - 2025-06-10 23:44:54 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', '', 'literasi', '1')
ERROR - 2025-06-10 23:45:03 --> Query error: Duplicate entry 'Literasi-post' for key 'unique_field' - Invalid query: INSERT INTO `categories` (`category_type`, `category_name`, `category_description`, `category_slug`, `created_by`) VALUES ('post', 'Literasi', '', 'literasi', '1')
ERROR - 2025-06-10 18:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 18:54:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:09:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:09:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:11:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:11:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:11:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:11:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:16:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:16:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:19:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:19:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:19:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:19:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:26:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:26:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:26:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:26:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:38:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:38:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:39:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:39:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:40:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:40:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:41:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:42:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:43:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:44:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:45:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:45:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:45:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:45:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:46:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:46:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:46:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:46:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:48:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:48:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:52:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:53:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:54:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:55:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:56:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-06-10 19:56:03 --> 404 Page Not Found: Assets/plugins
