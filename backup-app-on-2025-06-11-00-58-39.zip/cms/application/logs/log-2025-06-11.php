<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-06-11 00:56:52 --> Severity: Notice --> Only variables should be assigned by reference C:\xampp\htdocs\cms\application\controllers\maintenance\Backup_database.php 38
